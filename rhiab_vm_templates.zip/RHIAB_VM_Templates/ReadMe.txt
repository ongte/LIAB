The ESXi v5.5 templates are HW v8 so that the Web Client is not required for management.  They
have been tested with the ESXi v6.0 vSphere Web Client and appear to work properly.

The Workstation v10 templates are HW v10.  They work fine in Workstation v11.


You WILL need to ensure that the proper Virtual Networks are chosen for the NICs.  The defaults
aren't reliable.



